part of 'home_screen.dart';

/// 루틴 스텝 데이터 모델
class _RoutineStep {
  final String emoji;
  final String label;
  final bool active;
  final String? time;
  final Color color;
  final String? endTime;
  final String? subtitle;
  final bool isLive;
  final VoidCallback? onToggle;
  final VoidCallback? onEdit;

  const _RoutineStep(
    this.emoji, this.label, this.active, this.time, {
    required this.color,
    this.endTime,
    this.subtitle,
    this.isLive = false,
    this.onToggle,
    this.onEdit,
  });
}

/// ═══════════════════════════════════════════════════
/// HOME — NFC 루틴 카드 + 외출/식사/일과종료
/// ═══════════════════════════════════════════════════
extension _HomeRoutineCard on _HomeScreenState {
  // ══════════════════════════════════════════
  //  ④ NFC 상태 카드 (프리미엄 리디자인)
  // ══════════════════════════════════════════

  Widget _nfcStatusCard() {
    final hasWake = _wake != null;
    final hasStudy = _studyStart != null;
    final bool isCurrentlyOut = _outing != null && _returnHome == null;
    final bool hasReturned = _outing != null && _returnHome != null;
    final hasBed = _bedTime != null;
    final ds = _nfc.state;

    // 루틴 스텝 정의 (토글 기반)
    final steps = <_RoutineStep>[
      _RoutineStep('☀️', '기상', hasWake, _wake,
        color: BotanicalColors.gold,
        onToggle: hasWake ? null : () => _quickWake(),
        onEdit: () => _editTimeField('wake', '기상시간', _wake)),
      _RoutineStep('📖', '공부', hasStudy, _studyStart,
        endTime: _studyEnd,
        color: BotanicalColors.primary,
        isLive: _ft.isRunning || (hasStudy && _studyEnd == null),
        onToggle: !hasStudy ? () => _nfc.manualTestRole(NfcTagRole.study).then((_) => _load()) : null,
        onEdit: () => _editTimeField('study', '공부시작', _studyStart)),
      _RoutineStep(isCurrentlyOut ? '🚶' : '🏠', '외출',
        isCurrentlyOut || hasReturned, isCurrentlyOut ? _outing : _returnHome,
        color: const Color(0xFF3B8A6B),
        isLive: isCurrentlyOut,
        onToggle: () => _toggleOuting(),
        onEdit: () => _editTimeField('outing', '외출', _outing)),
      _RoutineStep('🍽️', '식사',
        _todayMeals.isNotEmpty || _nfc.isMealing, null,
        color: const Color(0xFFFF8A65),
        subtitle: _todayMeals.isNotEmpty ? '${_todayMeals.length}회' : (_nfc.isMealing ? '식사 중' : null),
        onToggle: () => _nfc.manualTestRole(NfcTagRole.meal).then((_) => _load()),
        onEdit: () => _editTimeField('meal', '식사', null)),
      _RoutineStep('🌙', '취침', hasBed, _bedTime,
        color: const Color(0xFF6B5DAF),
        onToggle: !hasBed ? () => _nfc.manualTestRole(NfcTagRole.sleep).then((_) => _load()) : null,
        onEdit: () => _editTimeField('bedTime', '취침', _bedTime)),
    ];
    final doneCount = steps.where((s) => s.active).length;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _dk ? const Color(0xFF0F1825) : const Color(0xFFFDFAF4),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _border.withOpacity(0.15)),
        boxShadow: [BoxShadow(
          color: _dk ? Colors.black.withOpacity(0.3) : Colors.black.withOpacity(0.04),
          blurRadius: 20, offset: const Offset(0, 8))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── 헤더 ──
        Row(children: [
          Text('루틴', style: BotanicalTypo.heading(
            size: 15, weight: FontWeight.w800, color: _textMain)),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
            decoration: BoxDecoration(
              color: _accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(6)),
            child: Text('$doneCount/${steps.length}',
              style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: _accent))),
          const Spacer(),
          // NFC + 수정 버튼
          GestureDetector(
            onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => NfcScreen())).then((_) => _load()),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _border.withOpacity(0.2))),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.settings_rounded, size: 12, color: _textMuted),
                const SizedBox(width: 3),
                Text('설정', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w600, color: _textMuted)),
              ]))),
        ]),
        const SizedBox(height: 12),
        // ── 루틴 타임라인 ──
        ...steps.map((s) => _routineRow(s)),
        // ── 프로그레스 바 ──
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(3),
          child: LinearProgressIndicator(
            value: doneCount / steps.length,
            minHeight: 4,
            backgroundColor: _dk ? Colors.white.withOpacity(0.04) : Colors.black.withOpacity(0.03),
            valueColor: AlwaysStoppedAnimation(_accent))),
      ]),
    );
  }

  Widget _routineRow(_RoutineStep s) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: GestureDetector(
        onTap: s.active ? s.onEdit : s.onToggle,
        onLongPress: s.onEdit,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: s.active
              ? s.color.withOpacity(_dk ? 0.06 : 0.03)
              : (_dk ? Colors.white.withOpacity(0.02) : Colors.white.withOpacity(0.5)),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: s.active
              ? s.color.withOpacity(0.15) : _border.withOpacity(0.08))),
          child: Row(children: [
            Text(s.emoji, style: const TextStyle(fontSize: 18)),
            const SizedBox(width: 10),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text(s.label, style: TextStyle(fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: s.active ? s.color : _textMuted)),
                if (s.isLive) ...[
                  const SizedBox(width: 5),
                  _pulseDot(s.color),
                ],
              ]),
              if (s.subtitle != null)
                Text(s.subtitle!, style: TextStyle(fontSize: 10,
                  color: s.color.withOpacity(0.7))),
            ])),
            // 시간 표시
            if (s.time != null) ...[
              Text(s.time!, style: TextStyle(fontSize: 14,
                fontWeight: FontWeight.w800,
                color: s.active ? (_dk ? Colors.white.withOpacity(0.9) : s.color) : _textMuted)),
              if (s.endTime != null) ...[
                Text(' → ', style: TextStyle(fontSize: 10, color: _textMuted)),
                Text(s.endTime!, style: TextStyle(fontSize: 14,
                  fontWeight: FontWeight.w800, color: s.color.withOpacity(0.7))),
              ],
            ] else if (!s.active)
              Icon(Icons.touch_app_rounded, size: 16, color: _textMuted.withOpacity(0.3)),
          ]),
        ),
      ),
    );
  }

  /// 외출/귀가 토글 (버튼으로 직접 실행)
  Future<void> _toggleOuting() async {
    final d = _studyDate();
    final now = DateTime.now();
    final timeStr = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    final fb = FirebaseService();
    final records = await fb.getTimeRecords();
    final existing = records[d];

    if (_outing == null || (_outing != null && _returnHome != null)) {
      // 외출 시작
      await fb.updateTimeRecord(d, TimeRecord(
        date: d, wake: existing?.wake,
        study: existing?.study, studyEnd: existing?.studyEnd,
        outing: timeStr, returnHome: null,
        arrival: existing?.arrival, bedTime: existing?.bedTime,
        mealStart: existing?.mealStart, mealEnd: existing?.mealEnd,
        meals: existing?.meals,
      ));
      _nfc.forceOutState(true);

      // ★ #3: GPS 추적 시작 (수동 외출에서도 NFC와 동일하게 작동)
      // 즉시 UI 반영
      _safeSetState(() { _outing = timeStr; _returnHome = null; _outingMinutes = null; });
    } else if (_outing != null && _returnHome == null) {
      // 귀가
      await fb.updateTimeRecord(d, TimeRecord(
        date: d, wake: existing?.wake,
        study: existing?.study, studyEnd: existing?.studyEnd,
        outing: existing?.outing, returnHome: timeStr,
        arrival: existing?.arrival, bedTime: existing?.bedTime,
        mealStart: existing?.mealStart, mealEnd: existing?.mealEnd,
        meals: existing?.meals,
      ));
      _nfc.forceOutState(false);

      // 즉시 UI 반영
      final outMin = TimeRecord(date: d, outing: _outing, returnHome: timeStr).outingMinutes;
      _safeSetState(() {
        _returnHome = timeStr;
        _outingMinutes = outMin;
      });
      // Firebase 재로드로 확실한 동기화
      await Future.delayed(const Duration(milliseconds: 300));
      if (mounted) await _load();

      // 22시 이후 귀가 → 하루 마무리 제안
      if (now.hour >= 22 && mounted) {
        _showDayEndDialog(d);
      }
    }
  }

  /// 하루 마무리 다이얼로그 (22시 이후 귀가 시)
  Future<void> _showDayEndDialog(String dateStr) async {
    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('🌙 하루 마무리', style: BotanicalTypo.heading(
          size: 18, weight: FontWeight.w800)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('오늘 하루 수고하셨습니다.\n공부를 종료하고 하루를 마무리할까요?',
            style: TextStyle(fontSize: 14, color: _textSub, height: 1.5)),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: BotanicalColors.primary.withOpacity(_dk ? 0.08 : 0.04),
              borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              Text('📚', style: const TextStyle(fontSize: 20)),
              const SizedBox(width: 10),
              Text('순공 ${_effMin ~/ 60}h ${_effMin % 60}m',
                style: BotanicalTypo.label(size: 14, weight: FontWeight.w800,
                  color: BotanicalColors.primary)),
              const Spacer(),
              if (_grade != null)
                Text('${_grade!.grade} ${_grade!.totalScore.toStringAsFixed(0)}점',
                  style: BotanicalTypo.label(size: 13, weight: FontWeight.w700,
                    color: BotanicalColors.gradeColor(_grade!.grade))),
            ]),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false),
            child: Text('아직', style: TextStyle(color: _textMuted))),
          ElevatedButton(
            onPressed: () => Navigator.pop(c, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF2D5F2D),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            child: const Text('마무리', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
    if (confirm == true && mounted) {
      // 공부종료 기록
      final now = DateTime.now();
      final endStr = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
      final fb = FirebaseService();
      final records = await fb.getTimeRecords();
      final existing = records[dateStr];
      if (existing != null && existing.studyEnd == null) {
        await fb.updateTimeRecord(dateStr, TimeRecord(
          date: dateStr, wake: existing.wake,
          study: existing.study, studyEnd: endStr,
          outing: existing.outing, returnHome: existing.returnHome,
          arrival: existing.arrival, bedTime: existing.bedTime,
          mealStart: existing.mealStart, mealEnd: existing.mealEnd,
          meals: existing.meals,
        ));
      }
      _load();
    }
  }

  // _actionButton 제거됨 → _statusActionBtn으로 대체

  // _statusBlockTappable 제거됨 → _statusNode로 대체

  int _calcOutingElapsed() {
    if (_outing == null) return 0;
    try {
      final p = _outing!.split(':');
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day,
        int.parse(p[0]), int.parse(p[1]));
      return now.difference(start).inMinutes.clamp(0, 1440);
    } catch (_) { return 0; }
  }

  // _outingStatsBar 제거됨 → 상태카드 내 인라인으로 통합
  // _connector 제거됨 → _dayProgressDots로 대체

  Future<void> _editTimeField(String field, String label, String? current) async {
    final d = _studyDate();
    final fb = FirebaseService();
    final records = await fb.getTimeRecords();
    final existing = records[d];
    if (!mounted) return;

    final result = await showModalBottomSheet<TimeRecord>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatusEditorSheet(existing: existing, dk: _dk, highlightField: field),
    );
    if (result == null) return;

    // ★ v11: TimeRecord 직접 반환 (식사 편집 포함)
    final updated = TimeRecord(
      date: d, wake: result.wake, study: result.study,
      studyEnd: result.studyEnd, outing: result.outing,
      returnHome: result.returnHome,
      arrival: result.arrival ?? existing?.arrival,
      bedTime: result.bedTime,
      mealStart: result.mealStart, mealEnd: result.mealEnd,
      meals: result.meals,
    );
    await fb.updateTimeRecord(d, updated);
    if (updated.outing != null && updated.returnHome == null) {
      _nfc.forceOutState(true);
    } else {
      _nfc.forceOutState(false);
    }
    if (updated.study != null && updated.studyEnd == null) {
      _nfc.forceStudyState(true);
    } else {
      _nfc.forceStudyState(false);
    }
    // ★ Rule C: _load() 재호출 없이 즉시 UI 반영 (Optimistic UI)
    _safeSetState(() {
      _wake = updated.wake;
      _studyStart = updated.study;
      _studyEnd = updated.studyEnd;
      _outing = updated.outing;
      _returnHome = updated.returnHome;
      _bedTime = updated.bedTime;
      _mealStart = updated.mealStart;
      _mealEnd = updated.mealEnd;
      if (updated.meals != null) _todayMeals = updated.meals!;
    });

    // 💌 다영에게 알리기 SnackBar
    final roleMap = {'wake': 'wake', 'outing': 'outing', 'study': 'study'};
    final timeMap = {'wake': updated.wake, 'outing': updated.outing, 'study': updated.study};
    final tgRole = roleMap[field];
    final tgTime = timeMap[field];
    if (tgRole != null && tgTime != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('$tgTime 저장됨'),
        action: SnackBarAction(
          label: '📩 다영에게 알리기',
          onPressed: () => TelegramService().sendNfc('$tgRole $tgTime'),
        ),
        duration: const Duration(seconds: 4),
      ));
    }
  }

  String _formatMin(int min) {
    final h = min ~/ 60; final m = min % 60;
    if (h > 0 && m > 0) return '${h}h ${m}m';
    if (h > 0) return '${h}h';
    return '${m}m';
  }

  // ★ v11: 식사 타입 헬퍼
  String _mealTypeEmoji(String? type) {
    switch (type) {
      case 'breakfast': return '🌅';
      case 'lunch': return '☀️';
      case 'dinner': return '🌙';
      case 'snack': return '🍪';
      default: return '🍽️';
    }
  }

  String _mealTypeLabel(String? type) {
    switch (type) {
      case 'breakfast': return '아침';
      case 'lunch': return '점심';
      case 'dinner': return '저녁';
      case 'snack': return '간식';
      default: return '식사';
    }
  }

  String _fmt12h(String? hhmm) {
    if (hhmm == null || !hhmm.contains(':')) return '--:--';
    try {
      final p = hhmm.split(':');
      final h = int.parse(p[0]); final m = p[1];
      final prefix = h < 12 ? '오전' : '오후';
      final h12 = h == 0 ? 12 : (h > 12 ? h - 12 : h);
      return '$prefix $h12:$m';
    } catch (_) { return hhmm; }
  }

  Widget _pulseDot(Color c) => Container(width: 8, height: 8,
    decoration: BoxDecoration(color: c, shape: BoxShape.circle,
      boxShadow: [BoxShadow(color: c.withOpacity(0.5), blurRadius: 6, spreadRadius: 1)]));

  Future<void> _quickWake() async {
    await WakeService().recordWake();
    await _load();  // reload to show updated time
  }

}
