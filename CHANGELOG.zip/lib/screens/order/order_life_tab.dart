import 'package:flutter/material.dart';
import 'order_theme.dart';

/// 인생경로 탭 — 준비 중 (stub)
class OrderLifeTab extends StatelessWidget {
  const OrderLifeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 80, height: 80,
            decoration: BoxDecoration(
              color: OC.accent.withOpacity(0.08),
              shape: BoxShape.circle),
            child: Icon(Icons.route_rounded, size: 36,
              color: OC.accent.withOpacity(0.5)),
          ),
          const SizedBox(height: 20),
          Text('인생경로', style: TextStyle(
            fontSize: 20, fontWeight: FontWeight.w800, color: OC.text1)),
          const SizedBox(height: 8),
          Text('준비 중입니다', style: TextStyle(
            fontSize: 14, color: OC.text3)),
          const SizedBox(height: 4),
          Text('장기 목표와 커리어 패스를 설계합니다', style: TextStyle(
            fontSize: 12, color: OC.text3.withOpacity(0.6))),
        ]),
      ),
    );
  }
}
