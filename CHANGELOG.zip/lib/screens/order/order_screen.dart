import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import '../../models/order_models.dart';
import '../../services/firebase_service.dart';
import 'order_theme.dart';
import 'order_goals_tab.dart';
import 'order_habits_tab.dart';
import 'order_expense_tab.dart';
import 'order_life_tab.dart';

/// ═══════════════════════════════════════════════════════════
/// CHEONHONG STUDIO — COMPASS PORTAL v4.0
/// 메인 스캐폴드 · 네비게이션 · 상태 관리
/// + NFC 실시간 연동 · Overwatch 자동감지 · 습관 큐 시스템
/// ═══════════════════════════════════════════════════════════

class OrderScreen extends StatefulWidget {
  const OrderScreen({super.key});
  @override State<OrderScreen> createState() => _OrderScreenState();
}

class _OrderScreenState extends State<OrderScreen>
    with SingleTickerProviderStateMixin {
  final _fb = FirebaseService();
  OrderData _data = OrderData();
  bool _loading = true;
  int _tab = 0;

  late AnimationController _blobCtrl;

  @override
  void initState() {
    super.initState();
    _blobCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 8))..repeat();
    _load();
  }

  @override
  void dispose() {
    _blobCtrl.dispose();
    super.dispose();
  }

  void _safeSetState(VoidCallback fn) {
    if (!mounted) return;
    final phase = SchedulerBinding.instance.schedulerPhase;
    if (phase == SchedulerPhase.persistentCallbacks ||
        phase == SchedulerPhase.midFrameMicrotasks) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) setState(fn);
      });
    } else {
      setState(fn);
    }
  }

  // ═══ DATA ═══
  Future<void> _load() async {
    try {
      final raw = await _fb.getStudyData();
      if (raw != null) {
        final od = raw['orderData'];
        if (od is Map && od.isNotEmpty) {
          _data = OrderData.fromMap(Map<String, dynamic>.from(od));
        }
      }
    } catch (_) {}

    _safeSetState(() => _loading = false);
  }

  Future<void> _save() async {
    try { await _fb.updateField('orderData', _data.toMap()); } catch (_) {}
  }

  void _update(VoidCallback fn) {
    _safeSetState(fn);
    _save();
  }

  // _seed() 제거됨 — 시드 데이터를 Firestore에 쓰지 않음

  // ═══ BUILD ═══
  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark.copyWith(
        statusBarColor: Colors.transparent),
      child: Scaffold(
        backgroundColor: OC.bg,
        body: _loading
            ? const Center(child: CircularProgressIndicator(color: OC.accent))
            : Stack(children: [
                Positioned(top: -60, right: -40,
                  child: _meshSpot(OC.accent, 200, .06)),
                Positioned(bottom: 100, left: -60,
                  child: _meshSpot(OC.amber, 180, .05)),
                Positioned(top: 300, right: -80,
                  child: _meshSpot(OC.success, 160, .04)),
                SafeArea(child: Column(children: [
                  _nav(),
                  Expanded(child: IndexedStack(index: _tab, children: [
                    OrderGoalsTab(
                      data: _data, onUpdate: _update),
                    OrderHabitsTab(
                      data: _data, onUpdate: _update,
                      blobCtrl: _blobCtrl),
                    OrderExpenseTab(
                      data: _data, onUpdate: _update),
                    const OrderLifeTab(),
                  ])),
                ])),
              ]),
      ),
    );
  }

  Widget _meshSpot(Color c, double size, double op) => Container(
    width: size, height: size,
    decoration: BoxDecoration(shape: BoxShape.circle,
      gradient: RadialGradient(
        colors: [c.withOpacity(op), c.withOpacity(0)])),
  );

  // ═══ NAVIGATION ═══
  Widget _nav() {
    final tabs = [
      ('목표', Icons.flag_rounded),
      ('습관', Icons.local_fire_department_rounded),
      ('회계', Icons.receipt_long_rounded),
      ('경로', Icons.route_rounded),
    ];
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: OC.card, borderRadius: BorderRadius.circular(20),
        border: Border.all(color: OC.border.withOpacity(.5)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.04),
          blurRadius: 12, offset: const Offset(0, 4))]),
      child: Row(children: List.generate(tabs.length, (i) {
        final sel = _tab == i;
        return Expanded(child: GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            _safeSetState(() => _tab = i);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              color: sel ? OC.accent : Colors.transparent,
              borderRadius: BorderRadius.circular(16),
              boxShadow: sel
                  ? [BoxShadow(color: OC.accent.withOpacity(.25),
                      blurRadius: 8, offset: const Offset(0, 2))]
                  : null),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(tabs[i].$2, size: 20,
                color: sel ? Colors.white : OC.text3),
              const SizedBox(height: 2),
              Text(tabs[i].$1, style: TextStyle(
                fontSize: 10, fontWeight: FontWeight.w700,
                color: sel ? Colors.white : OC.text3)),
            ]),
          ),
        ));
      })),
    );
  }
}