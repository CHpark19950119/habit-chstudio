import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';
import '../utils/study_date_utils.dart';
import 'firebase_service.dart';
import 'nfc_service.dart';
import 'telegram_service.dart';

/// 기상 감지 인터페이스 — 나중에 센서 연동 시 교체
abstract class WakeDetector {
  Future<void> detectWake();
}

/// 수동 기상 (현재 사용)
class ManualWakeDetector implements WakeDetector {
  @override
  Future<void> detectWake() async {
    await WakeService().recordWake();
  }
}

/// 센서 기상 (stub, 미구현)
class SensorWakeDetector implements WakeDetector {
  @override
  Future<void> detectWake() async {
    // TODO: 센서 연동 시 _detectFromSensor()로 교체
    debugPrint('[WakeDetector] sensor not implemented');
  }
}

/// WakeService — 기상 기록 전용 서비스
class WakeService {
  static final WakeService _instance = WakeService._internal();
  factory WakeService() => _instance;
  WakeService._internal();

  WakeDetector _detector = ManualWakeDetector();
  WakeDetector get detector => _detector;
  void setDetector(WakeDetector d) => _detector = d;

  /// 기상 기록 — NfcService의 manualTestRole(wake) 위임
  Future<void> recordWake() async {
    final result = await NfcService().manualTestRole(NfcTagRole.wake);
    debugPrint('[WakeService] recordWake: $result');
  }
}
